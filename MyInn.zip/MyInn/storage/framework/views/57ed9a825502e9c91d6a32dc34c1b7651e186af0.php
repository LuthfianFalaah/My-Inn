<!DOCTYPE html>
<html>

<head>
    <title>My Inn</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.css">
    <script src="https://cdn.jsdelivr.net/npm/semantic-ui@2.4.2/dist/semantic.min.js"></script>

    <link href="<?php echo e(asset('css/homeusers.css')); ?>" rel="stylesheet">
</head>

<body>

    <div class="ui secondary  menu col-1" id="menuNavbar">
        <i class="huge home icon" id="iconMYINN"></i>
        <div id="nameID"><p>MY INN</p></div>
        <div class="ui fluid icon input" id="searchNavbar">
            <input type="text" placeholder="Masukan Kata Kunci . . . ">
            <i class="search icon"></i>
        </div>
        <a class="active item" id="itemNavbar">
            BANTUAN
        </a>
        <a class="item" id="itemNavbar">
            DAFTAR
        </a>
        <a class="item" id="itemNavbar">
            MASUK
        </a>
    </div>



</body>

</html>
<?php /**PATH F:\MyInn\resources\views/users/home.blade.php ENDPATH**/ ?>